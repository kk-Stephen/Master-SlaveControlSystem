import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error

# 从CSV文件中读取数据
df = pd.read_csv("D:\\PythonProject\\RS\e_v_data.csv")

# 假设 df 是你的 DataFrame
X = df[['vl', 'vr', 'ep']]
y = df['e']

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 选择多项式的阶数
degree = 1

# 创建多项式回归模型
model = make_pipeline(PolynomialFeatures(degree), LinearRegression())

# 训练模型
model.fit(X_train, y_train)

# 在测试集上进行预测
y_pred = model.predict(X_test)

# 评估模型性能
mse = mean_squared_error(y_test, y_pred)
print("Mean Squared Error:", mse)

# 打印模型的系数
coefficients = model.named_steps['linearregression'].coef_
intercept = model.named_steps['linearregression'].intercept_

print("Intercept (theta_0):", intercept)
print("Coefficients (theta_1, theta_2, ...):", coefficients[1:])

